importScripts('/vendor/scramjet/scramjet.all.js');
const { ScramjetServiceWorker } = $scramjetLoadWorker();
const scramjet = new ScramjetServiceWorker();
self.addEventListener('install', () => self.skipWaiting());
self.addEventListener('activate', event => event.waitUntil(self.clients.claim()));
self.addEventListener('fetch',event=>{
  event.respondWith((async()=>{
    try {
      const response=await (async()=>{await scramjet.loadConfig();return scramjet.route(event)?scramjet.fetch(event):fetch(event.request);})();
      if(event.request.destination==='document'&&response.status>=400)await notify('The requested page returned HTTP '+response.status+'. Try the other proxy engine, or open the game directly.');
      return response;
    } catch(error) {
      await notify('Proxy request failed: '+String(error?.message||error));
      return new Response('Orbit could not load this page. Open Customize for the error report.',{status:502,headers:{'content-type':'text/plain'}});
    }
  })());
});
async function notify(message){for(const client of await self.clients.matchAll({type:'window',includeUncontrolled:true}))client.postMessage({type:'orbit-proxy-error',message});}
