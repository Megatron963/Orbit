importScripts('/vendor/uv/uv.bundle.js','/uv/uv.config.js','/vendor/uv/uv.sw.js');
const uv=new UVServiceWorker();
self.addEventListener('install',e=>e.waitUntil(self.skipWaiting()));
self.addEventListener('activate',e=>e.waitUntil(self.clients.claim()));
self.addEventListener('fetch',event=>{
  event.respondWith((async()=>{
    try {
      const response=await (async()=>{return uv.route(event)?uv.fetch(event):fetch(event.request);})();
      if(event.request.destination==='document'&&response.status>=400)await notify('The requested page returned HTTP '+response.status+'. Try the other proxy engine, or open the game directly.');
      return response;
    } catch(error) {
      await notify('Proxy request failed: '+String(error?.message||error));
      return new Response('Orbit could not load this page. Open Customize for the error report.',{status:502,headers:{'content-type':'text/plain'}});
    }
  })());
});
async function notify(message){for(const client of await self.clients.matchAll({type:'window',includeUncontrolled:true}))client.postMessage({type:'orbit-proxy-error',message});}
